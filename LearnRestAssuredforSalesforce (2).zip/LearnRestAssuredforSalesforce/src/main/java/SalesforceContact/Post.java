package SalesforceContact;

import org.testng.annotations.Test;
import io.restassured.http.ContentType;

public class Post extends BaseClass
{
	@Test
	public void postReq() {
				
				
	  response = inpReq			
				.contentType(ContentType.JSON)
				.body("{\r\n"
						+ "    \"FirstName\":\"Manoj\",\r\n"
						+ "    \"LastName\":\"Patil\"\r\n"
						+ "}")
				.post();
	  
	  gblvar = response.jsonPath().get("id");
	  response.prettyPrint();
	}
}
