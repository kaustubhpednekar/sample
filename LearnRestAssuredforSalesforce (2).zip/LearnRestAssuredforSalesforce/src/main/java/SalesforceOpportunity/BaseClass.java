package SalesforceOpportunity;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass 
{
	static RequestSpecification inpReq = null;
	static Response response = null;
	static String gblvar;
	
	@BeforeMethod
	public void preCond()
	{
        RestAssured.useRelaxedHTTPSValidation();
		
        RestAssured.baseURI = "https://ap16.salesforce.com/services/data/v20.0/sobjects/opportunity";
				
	    RestAssured.authentication = RestAssured.oauth2("00D5g000007oRrU!AQkAQOq0TSMeGwBCH0HFhvzLuY8zAtcAiMPH8XvAlxTnns1hXW1Wx0W6WMkXfkoMJN9M5EHlZYRi_IO412IAHzBJllx0vAj3");
	    
		inpReq = RestAssured.given()
				.log()
				.all();
	}
	
	@AfterMethod
	public void postCond()
	{
		response.prettyPrint();	

	}

}
