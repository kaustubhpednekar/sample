package SalesforceOpportunity;


import org.testng.annotations.Test;


public class Delete extends BaseClass 
{
	@Test(dependsOnMethods="SalesforceOpportunity.Post.postReq")
	public void deleteReq() {
		
						
	 response = inpReq.delete(gblvar);
	 
	 response.prettyPrint();
	 int status = response.statusCode();
	 System.out.println(status);
	}
}
