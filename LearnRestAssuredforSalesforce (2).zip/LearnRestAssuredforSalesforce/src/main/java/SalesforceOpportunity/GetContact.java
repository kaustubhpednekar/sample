package SalesforceOpportunity;


import org.testng.annotations.Test;


public class GetContact extends BaseClass
{
	@Test
	public void getReq() {
    
		response = inpReq.get();
		
		response.prettyPrint();	
	
	
	}
}
