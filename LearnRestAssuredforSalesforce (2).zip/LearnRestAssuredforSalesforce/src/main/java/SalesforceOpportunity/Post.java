package SalesforceOpportunity;

import org.testng.annotations.Test;
import io.restassured.http.ContentType;

public class Post extends BaseClass
{
	@Test
	public void postReq() {
				
				
	  response = inpReq			
				.contentType(ContentType.JSON)
				.body("{\r\n"
						+ "    \"CloseDate\":\"2022-05-18\",\r\n"
						+ "    \"Name\":\"demol\",\r\n"
						+ "    \"StageName\":\"Needs Analysis\"\r\n"
						+ "}")
				.post();
	  
	  gblvar = response.jsonPath().get("id");
	  response.prettyPrint();
	}
}
